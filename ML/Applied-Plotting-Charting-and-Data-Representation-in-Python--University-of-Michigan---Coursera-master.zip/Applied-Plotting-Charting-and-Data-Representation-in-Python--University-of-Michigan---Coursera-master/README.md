# Applied-Plotting-Charting-and-Data-Representation-in-Python--University-of-Michigan---Coursera
Course materials for the Coursera MOOC: Applied Plotting, Charting &amp; Data Representation in Python from University of Michigan, Course 2 of the Applied Data Science with Python Specialization
